package Class;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class Main {
    // Variable d'instance

    // Permet la lecture de la saisie utilisateur
    private static Scanner scanner = new Scanner(System.in, "UTF-8");
    private static List<Enseignant> enseignants = new ArrayList<>();
    private static List<Eleve> eleves = new ArrayList<>();
    private static List<Classe> classes = new ArrayList<>();
    private static List<Matiere> matieres = new ArrayList<>();
    private static List<Note> notes = new ArrayList<>();

    public static void main(String[] args) {
        // Entree de l'application 
        initialiserDonnees();
        afficherMenuPrincipal();
    }

    private static void initialiserDonnees() {
        // Creation des enseignants tests
        Enseignant enseignant1 = new Enseignant(1, "Franchini", "Jade", "Mathematiques", 1, 1);
        Enseignant enseignant2 = new Enseignant(2, "Arnold", "Anne-Charlotte", "Francais", 2, 2);
        Enseignant enseignant3 = new Enseignant(3, "Bachelot", "Susan", "Histoire", 3, 3);
        Enseignant enseignant4 = new Enseignant(4, "Cornec", "Maxence", "Physique", 4, 4);
        Enseignant enseignant5 = new Enseignant(5, "Perret", "Cheun", "Chimie", 5, 5);
        
        // Creation des eleves tests
        Eleve eleve1 = new Eleve(1, "Dupont", "Henry", 1);
        Eleve eleve2 = new Eleve(2, "Dupond", "Jacques", 1);
        Eleve eleve3 = new Eleve(3, "Le Gall", "Paul", 2);
        Eleve eleve4 = new Eleve(4, "Smith", "Pierre", 2);
        Eleve eleve5 = new Eleve(5, "Leroy", "Amelie", 2);
        
        // Creation des classes tests
        Classe classe1 = new Classe(1, "Seconde", "");
        Classe classe2 = new Classe(2, "Premiere", "");
        Classe classe3 = new Classe(3, "Terminale", "");
        
        // Creation Matiere
        Matiere matiere1 = new Matiere(1, "Mathematique"); 
        Matiere matiere2 = new Matiere(2, "Francais");
        Matiere matiere3 = new Matiere(3, "Histoire");
        Matiere matiere4 = new Matiere(4, "Physique");
        Matiere matiere5 = new Matiere(5, "Chimie");

        
        // Creation de notes 
        Note note1 = new Note(1, 1, 1, 8);
        Note note2 = new Note(2, 1, 2, 12);
        Note note3 = new Note(3, 2, 4, 13);
        Note note4 = new Note(4, 2, 1, 19);
        Note note5 = new Note(5, 3, 1, 3);
        Note note6 = new Note(6, 3, 1, 14);
        Note note7 = new Note(7, 4, 1, 8);
        Note note8 = new Note(8, 4, 1, 17);
        Note note9 = new Note(9, 5, 1, 11);

        // Ajout des enseignants e la liste
        enseignants.add(enseignant1);
        enseignants.add(enseignant2);
        enseignants.add(enseignant3);
        enseignants.add(enseignant4);
        enseignants.add(enseignant5);
        
        // Ajout des eleves e la liste 
        eleves.add(eleve1);
        eleves.add(eleve2);
        eleves.add(eleve3);
        eleves.add(eleve4);
        eleves.add(eleve5);
        
        // Ajout des classes 
        classes.add(classe1);
        classes.add(classe2);
        classes.add(classe3);
        
        // Ajout des matieres 
        matieres.add(matiere1);
        matieres.add(matiere2);
        matieres.add(matiere3);
        matieres.add(matiere4);
        matieres.add(matiere5);

        // Ajout des notes
        notes.add(note1);
        notes.add(note2);
        notes.add(note3);
        notes.add(note4);
        notes.add(note5);
        notes.add(note6);
        notes.add(note7);
        notes.add(note8);
        notes.add(note9);
    }

    private static void afficherMenuPrincipal() {
    	System.out.println("");
        System.out.println("Menu Principal :");
        System.out.println("1. Enseignants");
        System.out.println("2. Eleves");
        System.out.println("3. Classes");
        System.out.println("4. Matieres");
        System.out.println("5. Notes");
        System.out.println("0. Quitter");

        System.out.println("");
        System.out.print("Choisissez une option : ");
        int choixMenuPrincipal = scanner.nextInt();

        switch (choixMenuPrincipal) {
            case 1:
                afficherMenuClasse("Enseignants");
                break;
            case 2:
                afficherMenuClasse("Eleves");
                break;
            case 3:
                afficherMenuClasse("Classes");
                break;
            case 4:
                afficherMenuClasse("Matieres");
                break;
            case 5:
                afficherMenuClasse("Notes");
                break;
            case 0:
                System.out.println("Au revoir !");
                break;
            default:
                System.out.println("Option invalide, veuillez choisir e nouveau.");
                afficherMenuPrincipal();
        }
    }
    
    private static void listerEnseignants() {
        System.out.println("Liste des Enseignants :");
        for (Enseignant enseignant : enseignants) {
            System.out.println("ID: " + enseignant.getIdEnseignant() + ", Nom: " + enseignant.getNom() + ", Prenom: " + enseignant.getPrenom() + ", Specialite: " + enseignant.getSpecialite());
        }
    }

    private static void listerEleves() {
        System.out.println("Liste des Eleves :");
        for (Eleve eleve : eleves) {
            System.out.println("ID: " + eleve.getIdEleve() + ", Nom: " + eleve.getNom() + ", Prenom: " + eleve.getPrenom());
        }
    }

    private static void listerClasses() {
        System.out.println("Liste des Classes :");
        for (Classe classe : classes) {
            System.out.println("ID: " + classe.getIdClasse() + ", Nom: " + classe.getNomClasse());
        }
    }

    private static void listerMatieres() {
        System.out.println("Liste des Matieres :");
        for (Matiere matiere : matieres) {
            System.out.println("ID: " + matiere.getIdMatiere() + ", Nom: " + matiere.getNomMatiere());
        }
    }

    private static void listerNotes() {
        System.out.println("Liste des Notes :");
        for (Note note : notes) {
            System.out.println("ID: " + note.getIdNote() + ", ID Eleve: " + note.getIdEleve() + ", ID Matiere: " + note.getIdMatiere() + ", Valeur: " + note.getValeur());
        }
    }
    
    // Focntion de creation pour chaque class 
    private static void creerEnseignant() {
        System.out.println("Creation d'un nouvel enseignant :");

        System.out.print("Entrez l'ID de l'enseignant : ");
        int idEnseignant = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Entrez le nom de l'enseignant : ");
        String nomEnseignant = scanner.nextLine();

        System.out.print("Entrez le prenom de l'enseignant : ");
        String prenomEnseignant = scanner.nextLine();

        System.out.print("Entrez la specialite de l'enseignant : ");
        String specialiteEnseignant = scanner.nextLine();
        
        System.out.print("Entrez l'id classe de l'enseignant : ");
        int idClasseEnseignant = scanner.nextInt();
        
        System.out.print("Entrez l'id matiere de l'enseignant : ");
        int idMatiereEnseignant = scanner.nextInt();

        Enseignant nouvelEnseignant = new Enseignant(idEnseignant, nomEnseignant, prenomEnseignant, specialiteEnseignant, idClasseEnseignant, idMatiereEnseignant);
        enseignants.add(nouvelEnseignant);

        System.out.println("Enseignant ajoute avec succes !");
    }

    private static void creerEleve() {
        System.out.println("Creation d'un nouvel eleve :");

        System.out.print("Entrez l'ID de l'eleve : ");
        int idEleve = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Entrez le nom de l'eleve : ");
        String nomEleve = scanner.nextLine();

        System.out.print("Entrez le prenom de l'eleve : ");
        String prenomEleve = scanner.nextLine();
        
        System.out.print("Entrez l'id classe de l'eleve : ");
        int idClasseEleve = scanner.nextInt();

        Eleve nouvelEleve = new Eleve(idEleve, nomEleve, prenomEleve, idClasseEleve);
        eleves.add(nouvelEleve);

        System.out.println("Eleve ajoute avec succes !");
    }

    private static void creerClasse() {
        System.out.println("Creation d'une nouvelle classe :");

        System.out.print("Entrez l'ID de la classe : ");
        int idClasse = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Entrez le nom de la classe : ");
        String nomClasse = scanner.nextLine();
        
        System.out.print("Entrez le niveau de la classe : ");
        String niveauClasse = scanner.nextLine();

        Classe nouvelleClasse = new Classe(idClasse, nomClasse, niveauClasse);
        classes.add(nouvelleClasse);

        System.out.println("Classe ajoutee avec succes !");
    }

    private static void creerMatiere() {
        System.out.println("Creation d'une nouvelle matiere :");

        System.out.print("Entrez l'ID de la matiere : ");
        int idMatiere = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Entrez le nom de la matiere : ");
        String nomMatiere = scanner.nextLine();

        Matiere nouvelleMatiere = new Matiere(idMatiere, nomMatiere);
        matieres.add(nouvelleMatiere);

        System.out.println("Matiere ajoutee avec succes !");
    }

    private static void creerNote() {
        System.out.println("Creation d'une nouvelle note :");

        System.out.print("Entrez l'ID de la note : ");
        int idNote = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Entrez l'ID de l'eleve associe e la note : ");
        int idEleve = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Entrez l'ID de la matiere associee e la note : ");
        int idMatiere = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Entrez la valeur de la note : ");
        double valeurNote = scanner.nextDouble();

        Note nouvelleNote = new Note(idNote, idEleve, idMatiere, valeurNote);
        notes.add(nouvelleNote);

        System.out.println("Note ajoutee avec succes !");
    }
    
    // Fonctions pour supprimer un element dans la liste avec son id 
    private static void supprimerEnseignant() {
        System.out.println("Suppression d'un enseignant :");

        System.out.print("Entrez l'ID de l'enseignant e supprimer : ");
        int idEnseignant = scanner.nextInt();

        boolean enseignantTrouve = false;
        for (Iterator<Enseignant> iterator = enseignants.iterator(); iterator.hasNext();) {
            Enseignant enseignant = iterator.next();
            if (enseignant.getIdEnseignant() == idEnseignant) {
                iterator.remove();
                enseignantTrouve = true;
                System.out.println("Enseignant supprime avec succes !");
                break;
            }
        }

        if (!enseignantTrouve) {
            System.out.println("Enseignant non trouve.");
        }
    }
    
    private static void supprimerEleve() {
        System.out.println("Suppression d'un eleve :");

        System.out.print("Entrez l'ID de l'eleve e supprimer : ");
        int idEleve = scanner.nextInt();

        boolean eleveTrouve = false;
        for (Iterator<Eleve> iterator = eleves.iterator(); iterator.hasNext();) {
            Eleve eleve = iterator.next();
            if (eleve.getIdEleve() == idEleve) {
                iterator.remove();
                eleveTrouve = true;
                System.out.println("Eleve supprime avec succes !");
                break;
            }
        }

        if (!eleveTrouve) {
            System.out.println("Eleve non trouve.");
        }
    }

    private static void supprimerClasse() {
        System.out.println("Suppression d'une classe :");

        System.out.print("Entrez l'ID de la classe e supprimer : ");
        int idClasse = scanner.nextInt();

        boolean classeTrouvee = false;
        for (Iterator<Classe> iterator = classes.iterator(); iterator.hasNext();) {
            Classe classe = iterator.next();
            if (classe.getIdClasse() == idClasse) {
                iterator.remove();
                classeTrouvee = true;
                System.out.println("Classe supprimee avec succes !");
                break;
            }
        }

        if (!classeTrouvee) {
            System.out.println("Classe non trouvee.");
        }
    }

    private static void supprimerMatiere() {
        System.out.println("Suppression d'une matiere :");

        System.out.print("Entrez l'ID de la matiere e supprimer : ");
        int idMatiere = scanner.nextInt();

        boolean matiereTrouvee = false;
        for (Iterator<Matiere> iterator = matieres.iterator(); iterator.hasNext();) {
            Matiere matiere = iterator.next();
            if (matiere.getIdMatiere() == idMatiere) {
                iterator.remove();
                matiereTrouvee = true;
                System.out.println("Matiere supprimee avec succes !");
                break;
            }
        }

        if (!matiereTrouvee) {
            System.out.println("Matiere non trouvee.");
        }
    }

    private static void supprimerNote() {
        System.out.println("Suppression d'une note :");

        System.out.print("Entrez l'ID de la note e supprimer : ");
        int idNote = scanner.nextInt();

        boolean noteTrouvee = false;
        for (Iterator<Note> iterator = notes.iterator(); iterator.hasNext();) {
            Note note = iterator.next();
            if (note.getIdNote() == idNote) {
                iterator.remove();
                noteTrouvee = true;
                System.out.println("Note supprimee avec succes !");
                break;
            }
        }

        if (!noteTrouvee) {
            System.out.println("Note non trouvee.");
        }
    }
    
    // Mettre e jour les informations 
    private static void mettreAJourEnseignant() {
        System.out.println("Mise e jour d'un enseignant :");

        System.out.print("Entrez l'ID de l'enseignant e mettre e jour : ");
        int idEnseignant = scanner.nextInt();

        boolean enseignantTrouve = false;
        for (Enseignant enseignant : enseignants) {
            if (enseignant.getIdEnseignant() == idEnseignant) {
                System.out.print("Nouveau nom de l'enseignant : ");
                String nouveauNom = scanner.next();
                enseignant.setNom(nouveauNom);

                System.out.print("Nouveau prenom de l'enseignant : ");
                String nouveauPrenom = scanner.next();
                enseignant.setPrenom(nouveauPrenom);

                System.out.print("Nouvelle specialite de l'enseignant : ");
                String nouvelleSpecialite = scanner.next();
                enseignant.setSpecialite(nouvelleSpecialite);

                enseignantTrouve = true;
                System.out.println("Enseignant mis e jour avec succes !");
                break;
            }
        }

        if (!enseignantTrouve) {
            System.out.println("Enseignant non trouve.");
        }
    }
    
    private static void mettreAJourEleve() {
        System.out.println("Mise e jour d'un eleve :");

        System.out.print("Entrez l'ID de l'eleve e mettre e jour : ");
        int idEleve = scanner.nextInt();

        boolean eleveTrouve = false;
        for (Eleve eleve : eleves) {
            if (eleve.getIdEleve() == idEleve) {
                System.out.print("Nouveau nom de l'eleve : ");
                String nouveauNom = scanner.next();
                eleve.setNom(nouveauNom);

                System.out.print("Nouveau prenom de l'eleve : ");
                String nouveauPrenom = scanner.next();
                eleve.setPrenom(nouveauPrenom);

                eleveTrouve = true;
                System.out.println("Eleve mis e jour avec succes !");
                break;
            }
        }

        if (!eleveTrouve) {
            System.out.println("Eleve non trouve.");
        }
    }

    private static void mettreAJourClasse() {
        System.out.println("Mise e jour d'une classe :");

        System.out.print("Entrez l'ID de la classe e mettre e jour : ");
        int idClasse = scanner.nextInt();

        boolean classeTrouvee = false;
        for (Classe classe : classes) {
            if (classe.getIdClasse() == idClasse) {
                System.out.print("Nouveau nom de la classe : ");
                String nouveauNom = scanner.next();
                classe.setNomClasse(nouveauNom);

                classeTrouvee = true;
                System.out.println("Classe mise e jour avec succes !");
                break;
            }
        }

        if (!classeTrouvee) {
            System.out.println("Classe non trouvee.");
        }
    }

    private static void mettreAJourMatiere() {
        System.out.println("Mise e jour d'une matiere :");

        System.out.print("Entrez l'ID de la matiere e mettre e jour : ");
        int idMatiere = scanner.nextInt();

        boolean matiereTrouvee = false;
        for (Matiere matiere : matieres) {
            if (matiere.getIdMatiere() == idMatiere) {
                System.out.print("Nouveau nom de la matiere : ");
                String nouveauNom = scanner.next();
                matiere.setNomMatiere(nouveauNom);

                matiereTrouvee = true;
                System.out.println("Matiere mise e jour avec succes !");
                break;
            }
        }

        if (!matiereTrouvee) {
            System.out.println("Matiere non trouvee.");
        }
    }
    
    private static void mettreAJourNote() {
        System.out.println("Mise e jour d'une note :");

        System.out.print("Entrez l'ID de la note e mettre e jour : ");
        int idNote = scanner.nextInt();

        boolean noteTrouvee = false;
        for (Note note : notes) {
            if (note.getIdNote() == idNote) {
                System.out.print("Nouvelle valeur de la note : ");
                double nouvelleValeur = scanner.nextDouble();
                note.setValeur(nouvelleValeur);

                noteTrouvee = true;
                System.out.println("Note mise e jour avec succes !");
                break;
            }
        }

        if (!noteTrouvee) {
            System.out.println("Note non trouvee.");
        }
    }

    private static void afficherMenuClasse(String classe) {
        System.out.println("\nMenu " + classe + " :");
        System.out.println("1. Lister les elements");
        System.out.println("2. Creer un nouvel element");
        System.out.println("3. Supprimer un element");
        System.out.println("4. Mettre e jour un element");
        System.out.println("0. Retour");

        System.out.print("Choisissez une action : ");
        int choixMenuClasse = scanner.nextInt();

        switch (choixMenuClasse) {
            case 1:
            	switch (classe) {
	                case "Enseignants":
	                    listerEnseignants();
	                    afficherMenuClasse(classe);
	                    break;
	                case "Eleves":
	                    listerEleves();
	                    afficherMenuClasse(classe);
	                    break;
	                case "Classes":
	                    listerClasses();
	                    afficherMenuClasse(classe);
	                    break;
	                case "Matieres":
	                    listerMatieres();
	                    afficherMenuClasse(classe);
	                    break;
	                case "Notes":
	                    listerNotes();
	                    afficherMenuClasse(classe);
	                    break;
	                default:
	                    System.out.println("Classe invalide.");
	            }
                break;
            case 2:
            	switch (classe) {
	                case "Enseignants":
	                    creerEnseignant();
	                    afficherMenuClasse(classe);
	                    break;
	                case "Eleves":
	                	creerEleve();
	                	afficherMenuClasse(classe);
	                    break;
	                case "Classes":
	                	creerClasse();
	                	afficherMenuClasse(classe);
	                    break;
	                case "Matieres":
	                	creerMatiere();
	                	afficherMenuClasse(classe);
	                    break;
	                case "Notes":
	                	creerNote();
	                	afficherMenuClasse(classe);
	                    break;
	                default:
	                    System.out.println("Classe invalide.");
            	}
                break;
            case 3:
            	switch (classe) {
	                case "Enseignants":
	                    supprimerEnseignant();
	                    afficherMenuClasse(classe);
	                    break;
	                case "Eleves":
	                	supprimerEleve();
	                	afficherMenuClasse(classe);
	                    break;
	                case "Classes":
	                	supprimerClasse();
	                	afficherMenuClasse(classe);
	                    break;
	                case "Matieres":
	                	supprimerMatiere();
	                	afficherMenuClasse(classe);
	                    break;
	                case "Notes":
	                	supprimerNote();
	                	afficherMenuClasse(classe);
	                    break;
	                default:
	                    System.out.println("Classe invalide.");
	            }
                break;
            case 4:
            	switch (classe) {
	                case "Enseignants":
	                    mettreAJourEnseignant();
	                    afficherMenuClasse(classe);
	                    break;
	                case "Eleves":
	                	mettreAJourEleve();
	                	afficherMenuClasse(classe);
	                    break;
	                case "Classes":
	                	mettreAJourClasse();
	                	afficherMenuClasse(classe);
	                    break;
	                case "Matieres":
	                	mettreAJourMatiere();
	                	afficherMenuClasse(classe);
	                    break;
	                case "Notes":
	                	mettreAJourNote();
	                	afficherMenuClasse(classe);
	                    break;
	                default:
	                    System.out.println("Classe invalide.");
	            }
                break;
            case 0:
                afficherMenuPrincipal();
                break;
            default:
                System.out.println("Option invalide, veuillez choisir e nouveau.");
                afficherMenuClasse(classe);
        }
    }
}
